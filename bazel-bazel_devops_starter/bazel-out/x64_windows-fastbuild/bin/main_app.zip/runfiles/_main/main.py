from helper import greet

if __name__ == "__main__":
    print(greet("DevOps Engineer"))
    print(greet("I am new to DevOps, so learning it"))
